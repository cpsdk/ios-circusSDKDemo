//
//  YDMainCollectionViewCell.m
//  OpenLive
//
//  Created by 二哥 on 2017/11/22.
//  Copyright © 2017年 YunDianLianDong. All rights reserved.
//

#import "CPDeviceListCollectionViewCell.h"
//#import "CPDeviceListModel.h"
#import "UIImageView+WebCache.h"

@implementation CPDeviceListCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
}







@end
