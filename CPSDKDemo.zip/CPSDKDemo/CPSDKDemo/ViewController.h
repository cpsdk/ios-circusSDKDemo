//
//  ViewController.h
//  CPSDKDemo
//
//  Created by 二哥 on 2018/2/7.
//  Copyright © 2018年 ydld. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;


@end

