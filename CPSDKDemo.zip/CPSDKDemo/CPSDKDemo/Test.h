//
//  Test.h
//  CPSDKDemo
//
//  Created by 二哥 on 2018/3/22.
//  Copyright © 2018年 ydld. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Test : NSObject

@property(nonatomic,copy) NSString *testValue;

@end
